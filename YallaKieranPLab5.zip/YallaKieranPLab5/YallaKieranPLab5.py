#Kieran Yalla
#7/26/23
#Professor Phong Banh
#CMSC 135

def main():
    total = 0.0
    i = 0
    
    try:
        infile = open('numbers.txt', 'r')
        
        for line in infile:
            numbers = float(line)
            total += numbers
            i += 1
                    

        infile.close()

        average = total / i

        print(format(average,'.2f'))

    
    except IOError:
        print('An error occured trying to read the file.')

    except ValueError:
        print('Non-numeric data found in the file.')

    except:
        print('An error occured.')
        
main()
    

    
  
